<!DOCTYPE html>
<html>
<head>
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/wp.css')); ?>">
</head>

<body>
    <?php if(auth()->guard()->check()): ?>
      <?php echo e(Auth::user()->name); ?>

      <form method="POST" action="<?php echo e(url('/logout')); ?>">
        <?php echo e(csrf_field()); ?>

        <input type="submit" value="Logout">
      </form>
    <?php else: ?>

    <?php endif; ?>
      <a href="<?php echo e(route('login')); ?>">Log in</a>
      <a href="<?php echo e(route('register')); ?>">Register</a>
    <?php echo $__env->yieldContent('content'); ?>
</body>

</html><?php /**PATH /var/www/html/webAppDev/week9/prod/resources/views/layouts/master.blade.php ENDPATH**/ ?>