<?php $__env->startSection('title'); ?>
Update review
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Update review</h1>
    <form method="post" action= '<?php echo e(url("review/$review->id")); ?>'>
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>


    <?php if(count($errors)>0): ?>
    <div class="alert">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>

    <p>
      <label>Review rating</label>
      <input type="text" name="review_rating" value="<?php echo e($review->review_rating); ?>">
    </p>

    <p>
      <label>Review content</label>
      <textarea type="text" name="review_content" placeholder="<?php echo e($review->review_content); ?>"></textarea>
    </p>

    <input type="submit" value="Update">
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week9/prod-order/resources/views/products/review_edit_form.blade.php ENDPATH**/ ?>