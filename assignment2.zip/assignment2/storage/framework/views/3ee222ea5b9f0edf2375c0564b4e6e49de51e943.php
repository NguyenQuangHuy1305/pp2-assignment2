<?php $__env->startSection('title'); ?>
    User recommendation
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headline'); ?>
  <h1 class="display-4 fw-normal">User recommendation</h1>
  <p> Here you will find users that you might want to follow!</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <table style:>
        <tr bgcolor="#9966ff">
            <th>User</th>
            <th>Reason for recommendation</th>
        </tr>
        <?php $__currentLoopData = $recommended_users_reason1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommended_user_reason1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href = '<?php echo e(url("user/$recommended_user_reason1->id")); ?>'><?php echo e($recommended_user_reason1->name); ?></a></td>
                <td>Having highest number of likes</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $recommended_users_reason2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommended_user_reason2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href = '<?php echo e(url("user/$recommended_user_reason2->id")); ?>'><?php echo e($recommended_user_reason2->name); ?></a></td>
                <td>Wrote the most amount of reviews</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $recommended_users_reason3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommended_user_reason3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href = '<?php echo e(url("user/$recommended_user_reason3->id")); ?>'><?php echo e($recommended_user_reason3->name); ?></a></td>
                <td>Have the most followers</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week9/assignment2/resources/views/products/user_recommendation.blade.php ENDPATH**/ ?>