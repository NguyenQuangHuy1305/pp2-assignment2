<?php $__env->startSection('title'); ?>
Update review
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headline'); ?>
  <h1 class="display-4 fw-normal">Update a review</h1>
  <p> You can update your review for <?php echo e($product->name); ?> here! </p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form method="post" action= '<?php echo e(url("review/$review->id")); ?>'>
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>


    <?php if(count($errors)>0): ?>
    <div class="alert">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>

    <p>
      <label>Review rating</label>
      <input type="text" name="review_rating" value="<?php echo e($review->review_rating); ?>">
    </p>

    <p>
      <label>Review content</label>
      <textarea type="text" name="review_content" placeholder="<?php echo e($review->review_content); ?>"></textarea>
    </p>

    <input type="submit" id="submit" value="Update">
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week9/assignment2/resources/views/products/review_edit_form.blade.php ENDPATH**/ ?>