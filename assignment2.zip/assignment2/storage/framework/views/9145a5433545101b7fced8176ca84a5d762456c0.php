<?php $__env->startSection('title'); ?>
  Product detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headline'); ?>
  <h1 class="display-4 fw-normal"><?php echo e($product->name); ?></h1>
  <p>Price: <?php echo e($product->price); ?></p>
  <p>Manufacturer: <?php echo e($product->manufacturer->name); ?></p>
  <p>Description: <?php echo e($product->description); ?></p>
  
  <!-- show edit button if the user is logged in and is a moderator -->
    <?php if (Auth::check() && Auth::user()->role == 'moderator') { ?>
    
    <p><a style="min-width: 200px" class="btn btn-outline-secondary" href = '<?php echo e(url("product/$product->id/edit")); ?>'>Edit</a></p>
  <?php } ?>

  <!-- show delete button if the user is logged in and is a moderator -->
  <?php if (Auth::check() && Auth::user()->role == 'moderator') { ?>
    <p>
      <form id="deleteitem" method="POST" action = '<?php echo e(url("product/$product->id")); ?>'>
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('DELETE')); ?>

        <input class="btn btn-secondary" type="submit" id="submit1" value="Delete">
      </form>
    </p>
  <?php } ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  <?php if(count($error)>0): ?>
    <p style="color:red;"><?php echo e($error[0]); ?></p>
  <?php endif; ?>
  
  <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img src="<?php echo e(asset('images/'.$image->image_path)); ?>" height="300">
    <p><i>image uploaded by <?php echo e($image->user_name); ?></i></p>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php if(count($reviews) > 0): ?>
    <!-- show reviews table here -->
    <table style:>
    <tr bgcolor="#9966ff">
      <th>Reviewer's name</th>
      <th>Reviewer's rating</th>
      <th>Review content</th>
      <th>Review created at</th>
      <?php if(auth()->guard()->check()): ?>
        <th>Like</th>
        <th>Dislike</th>
        <th>Update</th>
        <th>Delete</th>
      <?php endif; ?>
    </tr>
      <!-- loop through all reviews, each review is a row in the table -->
      <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
        // dd($review);
        $review_id = $review->id;
        $user_id = $review->user_id;
        if ($review->like_count > $review->dislike_count) { ?>
        <tr bgcolor="#66ff66">
        <?php } elseif ($review->like_count < $review->dislike_count) { ?>
        <tr bgcolor="#ff9966">
        <?php } ?>
        
          <td>
            <?php echo e($review->user_name); ?>

            <?php if(auth()->guard()->check()): ?>
            <?php
              if (Auth::user()->id != $user_id) {
                $follow = DB::table('follows')->where('follower_user_id', Auth::user()->id)->where('followed_user_id', $user_id)->get();
                if ($follow->isEmpty()) { ?>
                  <a href = '<?php echo e(url("follow/$user_id")); ?>'> Follow</a>
                <?php } elseif (count($follow) > 0) { ?>
                  <a href = '<?php echo e(url("unfollow/$user_id")); ?>'> Unfollow</a>
                <?php }
              }?>
            <?php endif; ?>
          </td>

          <td><?php echo e($review->review_rating); ?></td>
          <td><?php echo e($review->review_content); ?></td>
          <td><?php echo e($review->created_at); ?></td>

          <?php if(auth()->guard()->check()): ?>

            <td>
              <?php
                $like = DB::table('likes')->where('user_id', Auth::user()->id)->where('review_id', $review->id)->get();
                if ($like->isEmpty()) { ?>
                  <a href = '<?php echo e(url("liked/$review_id")); ?>'><img src="<?php echo e(asset('images/'.'like.png')); ?>" width="20"></a>
                <?php } elseif (count($like) > 0) { ?>
                  <a href = '<?php echo e(url("liked/$review_id")); ?>'><img src="<?php echo e(asset('images/'.'liked.png')); ?>" width="20"></a>
                <?php } ?>
                  <?php echo e($review->like_count); ?>

            </td>

            <td>
              <?php
                $dislike = DB::table('dislikes')->where('user_id', Auth::user()->id)->where('review_id', $review->id)->get();
                if ($dislike->isEmpty()) { ?>
                  <a href = '<?php echo e(url("disliked/$review_id")); ?>'><img src="<?php echo e(asset('images/'.'dislike.png')); ?>" width="20"></a>
                <?php } elseif (count($dislike) > 0) { ?>
                  <a href = '<?php echo e(url("disliked/$review_id")); ?>'><img src="<?php echo e(asset('images/'.'disliked.png')); ?>" width="20"></a>
                <?php } ?>
                  <?php echo e($review->dislike_count); ?>

            </td>

            <?php if (Auth::user()->id == $review->user_id || Auth::user()->role == 'moderator') { ?>

            <td><a href = '<?php echo e(url("review/$review_id/edit")); ?>'>Update</a></td> 
            
            <td>          
              <form id="deletereview" method="POST" action = '<?php echo e(url("review/$review_id")); ?>'>
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <input type="submit" value="Delete">
              </form>
            </td>
            
            <?php } ?>

          <?php endif; ?>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  <?php else: ?>
  <p style="color: red"> This product doesn't have any review yet, you can write your review for this product by clicking this button below </p>
  <?php endif; ?>
  
  <nav aria-label="Page navigation example">
    <ul class="pagination justify-content-center">
      <?php echo e($reviews->links()); ?>

    </ul>
  </nav>

  <?php if(auth()->guard()->check()): ?>
  <a style="min-width: 755px" class="btn btn-outline-secondary" href='<?php echo e(url("review/create")); ?>'>Review this product</a>
  <br>

  <form style="margin-top: 20px;" method="POST" action = '<?php echo e(url("image")); ?>' enctype = 'multipart/form-data'>
    <?php echo e(csrf_field()); ?>

    <input type = 'file' name='image'>
    <input type="submit" value="Upload">
  </form>
  <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week9/assignment2/resources/views/products/show.blade.php ENDPATH**/ ?>