<!DOCTYPE html>
<html>
<head>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

  <title><?php echo $__env->yieldContent('title'); ?></title>

  <style>
  table, th, td {
    border: 1.5px solid black;
    text-align: center;
  }
  </style>
  
</head>

<body>
    <?php if(auth()->guard()->check()): ?>
      User name: <?php echo e(Auth::user()->name); ?> <br>
      User type: 
      <?php if( Auth::user()->role == 'moderator'): ?>
        Moderator
      <?php else: ?>
        Member
      <?php endif; ?>

      <form method="POST" action="<?php echo e(url('/logout')); ?>">
        <?php echo e(csrf_field()); ?>

        <input type="submit" value="Logout">
      </form>
    <?php else: ?>
    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>
      <a href="<?php echo e(route('login')); ?>">Log in</a>
      <a href="<?php echo e(route('register')); ?>">Register</a>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

    <p><a href="<?php echo e(url('product')); ?>">Home</a></p>

</body>

</html><?php /**PATH /var/www/html/webAppDev/week9/assignment2/resources/views/layouts/master.blade.php ENDPATH**/ ?>