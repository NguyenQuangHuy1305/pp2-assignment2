<?php $__env->startSection('title'); ?>
  User's profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1> <?php echo e($user->name); ?> </h1>
  <p> Email: <?php echo e($user->email); ?>

    <ul>

    <?php
        if (count($users) > 0) { ?>
          <p>Followed people list: </p>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><p><a href = '<?php echo e(url("user/$user->id")); ?>'><?php echo e($user->name); ?></a></p></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php } else { ?>
          <p> You haven't followed anyone
        <?php } ?>

    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week9/prod-order/resources/views/products/personal_profile.blade.php ENDPATH**/ ?>