<?php $__env->startSection('title'); ?>
  User's profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1> <?php echo e($user->name); ?> </h1>
  <p> Email: <?php echo e($user->email); ?>

  
  <table style:>
  <p> <?php echo e($user->name); ?>'s reviews: </p>
  <tr bgcolor="#9966ff">
    <th>Reviewer's name</th>
    <th>Reviewed product</th>
    <th>Reviewer's rating</th>
    <th>Review content</th>
    <th>Review created at</th>
    <?php if(auth()->guard()->check()): ?>
      <th>Like</th>
      <th>Dislike</th>
    <?php endif; ?>
  </tr>
    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      // dd($review);
      $review_id = $review->pivot->id;
      $user_id = $review->pivot->user_id;
      if ($review->pivot->like_count > $review->pivot->dislike_count) { ?>
      <tr bgcolor="#66ff66">
      <?php } elseif ($review->pivot->like_count < $review->pivot->dislike_count) { ?>
      <tr bgcolor="#ff9966">
      <?php } ?>
      
        <td>
          <?php echo e($review->pivot->user_name); ?>


          <?php

          if (Auth::user()->id != $user_id) {
            $follow = DB::table('follows')->where('follower_user_id', Auth::user()->id)->where('followed_user_id', $user_id)->get();
            if ($follow->isEmpty()) { ?>
              <a href = '<?php echo e(url("follow/$user_id")); ?>'> Follow</a>
            <?php } elseif (count($follow) > 0) { ?>
              <a href = '<?php echo e(url("unfollow/$user_id")); ?>'> Unfollow</a>
            <?php }
          }?>

        </td>

        <td><a href = '<?php echo e(url("product/$review->id")); ?>'><?php echo e($review->name); ?></a></td>
        <td><?php echo e($review->pivot->review_rating); ?></td>
        <td><?php echo e($review->pivot->review_content); ?></td>
        <td><?php echo e($review->pivot->created_at); ?></td>

        <?php if(auth()->guard()->check()): ?>

          <td>
            <?php
              $like = DB::table('likes')->where('user_id', Auth::user()->id)->where('review_id', $review->pivot->id)->get();
              if ($like->isEmpty()) { ?>
                <a href = '<?php echo e(url("liked/$review_id")); ?>'><img src="<?php echo e(asset('images/'.'like.png')); ?>" width="20"></a>
              <?php } elseif (count($like) > 0) { ?>
                <a href = '<?php echo e(url("liked/$review_id")); ?>'><img src="<?php echo e(asset('images/'.'liked.png')); ?>" width="20"></a>
              <?php } ?>
                <?php echo e($review->pivot->like_count); ?>

          </td>

          <td>
            <?php
              $dislike = DB::table('dislikes')->where('user_id', Auth::user()->id)->where('review_id', $review->pivot->id)->get();
              if ($dislike->isEmpty()) { ?>
                <a href = '<?php echo e(url("disliked/$review_id")); ?>'><img src="<?php echo e(asset('images/'.'dislike.png')); ?>" width="20"></a>
              <?php } elseif (count($dislike) > 0) { ?>
                <a href = '<?php echo e(url("disliked/$review_id")); ?>'><img src="<?php echo e(asset('images/'.'disliked.png')); ?>" width="20"></a>
              <?php } ?>
                <?php echo e($review->pivot->dislike_count); ?>

          </td>

        <?php endif; ?>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week9/prod-order/resources/views/products/profile.blade.php ENDPATH**/ ?>