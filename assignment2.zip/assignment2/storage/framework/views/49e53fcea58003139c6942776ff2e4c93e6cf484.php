<?php $__env->startSection('title'); ?>
  Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1> Products </h1>
  <?php if($products): ?>
    <ul>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><a href="product/<?php echo e($product->id); ?>"> <?php echo e($product->name); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <p><a href = '<?php echo e(url("product/create")); ?>'>Create</a></p>
  <?php else: ?>
    No item found
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week9/prod/resources/views/products/index.blade.php ENDPATH**/ ?>