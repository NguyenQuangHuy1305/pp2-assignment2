<?php $__env->startSection('title'); ?>
    Product recommendation
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headline'); ?>
  <h1 class="display-4 fw-normal">Product recommendation</h1>
  <p> Here you will find products that might interest you! </p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        use App\Models\Manufacturer;
    ?>

    <table style:>
        <tr bgcolor="#9966ff">
            <th>Product</th>
            <th>Reason for recommendation</th>
        </tr>
        <?php $__currentLoopData = $recommended_products_reason1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommended_product_reason1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href = '<?php echo e(url("product/$recommended_product_reason1->id")); ?>'><?php echo e($recommended_product_reason1->name); ?></a></td>
                <td>Having highest average rating among all products</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $recommended_products_reason2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommended_product_reason2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href = '<?php echo e(url("product/$recommended_product_reason2->id")); ?>'><?php echo e($recommended_product_reason2->name); ?></a></td>
                <td>The people you followed liked these products</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $recommended_products_reason3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommended_product_reason3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $manufacturer = Manufacturer::find($recommended_product_reason3->manufacturer_id);
            ?>

            <tr>
                <td><a href = '<?php echo e(url("product/$recommended_product_reason3->id")); ?>'><?php echo e($recommended_product_reason3->name); ?></a></td>
                <td>Because you liked products from <?php echo e($manufacturer->name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week9/assignment2/resources/views/products/product_recommendation.blade.php ENDPATH**/ ?>